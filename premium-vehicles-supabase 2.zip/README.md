Premium Vehicles - Next.js + Supabase demo
=========================================

WHAT'S INCLUDED
- Next.js app (pages: /, /admin)
- Tailwind CSS for styling
- Supabase client configured (lib/supabaseClient.js) using the keys you provided.
- SQL migration file: supabase_init.sql (create 'vehicles' table)

IMPORTANT: SECURITY
- You provided the public anon key and URL; these are used by frontend to access Supabase.
- Never share the service_role key. Keep it secret.

SETUP (quick)
1. Open Supabase Dashboard -> SQL Editor. Run `supabase_init.sql` to create the 'vehicles' table.
2. Option A (Local):
   - Install dependencies: npm install
   - Create .env.local with:
     NEXT_PUBLIC_SUPABASE_URL=https://ppwixsyjzmwvjuwpwswp.supabase.co
     NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InBwd2l4c3lqem13dmp1d3B3c3dwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjA2MDkxMTUsImV4cCI6MjA3NjE4NTExNX0.7N6WRF3fuZFT86MhlQV-fqRmuWN7RgpLrgiSfyKNDTc
   - Run locally: npm run dev
3. Option B (Codesandbox / Stackblitz / Vercel):
   - Upload the project folder or import the GitHub repo.
   - Set environment variables in the hosting platform:
     NEXT_PUBLIC_SUPABASE_URL and NEXT_PUBLIC_SUPABASE_ANON_KEY
   - Deploy. For Vercel use 'Deploy' and set env vars on Vercel dashboard.

SUPABASE AUTH SETUP (Phone OTP)
- In Supabase Dashboard -> Authentication -> Settings -> Enable 'Phone' as a sign-in provider.
- Configure SMS provider (for production) OR use built-in test phone numbers for development.

USAGE
- Visit /admin to sign in with phone (OTP) and add vehicles.
- Vehicles are stored in the 'vehicles' table and displayed on the homepage.

SECURITY NOTE
- Current example allows authenticated users (any phone) to add vehicles.
- For a protected admin, create a 'admins' table and check user's phone against it before allowing create/delete.